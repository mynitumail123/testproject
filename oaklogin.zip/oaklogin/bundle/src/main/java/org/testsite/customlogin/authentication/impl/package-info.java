@Version("1.0.0")
package org.testsite.customlogin.authentication.impl;

import aQute.bnd.annotation.Version;