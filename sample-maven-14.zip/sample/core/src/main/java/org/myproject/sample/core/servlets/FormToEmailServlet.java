package org.myproject.sample.core.servlets;

import java.io.IOException;
import java.rmi.ServerException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;

@Component(service=Servlet.class,
property={
        Constants.SERVICE_DESCRIPTION + "=Form to Email Servlet",
        "sling.servlet.methods=" + HttpConstants.METHOD_POST,
        "sling.servlet.paths="+ "/bin/formtoemail"
})

public class FormToEmailServlet  extends SlingAllMethodsServlet{
	
	@Override
    public void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
            throws ServletException, IOException{
    	
    	System.out.println("FormToEmailServlet.doGet()");
    }
	
	@Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {
	      	try
	      {
			System.out.println("FormToEmailServlet.doPost()");
			
			String firstName = request.getParameter("firstName");
	          String lastName = request.getParameter("lastName");
	          
	          System.out.println("First Name " + firstName);
	          
			
	      }
	      catch(Exception e)
	      {
	          e.printStackTrace();
	      }
	}
      

}
