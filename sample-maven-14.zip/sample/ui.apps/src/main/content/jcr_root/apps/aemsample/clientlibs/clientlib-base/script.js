$(document).ready(function() {
	$('body').hide().fadeIn(5000);

	$('#submit').click(function() {
		var failure = function(err) {
			alert("Unable to retrive data " + err);
		};

		var myFirst = $('#FirstName').val();
		var myLast = $('#LastName').val();
		var claimId = 0;

		//Use JQuery AJAX request to post data to a Sling Servlet
		$.ajax({
			type : 'POST',
			url : '/bin/formtoemail',
			data : 'firstName=' + myFirst + '&lastName=' + myLast,

			success : function(msg) {

				var myMsg = msg;

				alert(myMsg);

			}
		});
	});

});